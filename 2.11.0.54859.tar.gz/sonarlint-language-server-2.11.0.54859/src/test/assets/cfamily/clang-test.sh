#!/bin/sh

printf "#include <...> search starts here:\nEnd of search list.\n" >&2

echo "#define __cplusplus 201703"
